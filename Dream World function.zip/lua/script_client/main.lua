print('script_client:hello world')


UI:openWindow("http")

